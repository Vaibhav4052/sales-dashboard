# 📊 Sales Dashboard (Python + Pandas + Power BI)

Analyzed **50,000+ sales records** using **Python (Pandas)** and built an **interactive Power BI dashboard** to track key sales KPIs including revenue, customer churn, and top-performing products.

## 🚀 Features
- Data Cleaning & Analysis: Python (Pandas, NumPy, Matplotlib, Seaborn)
- Interactive Dashboard: Power BI
- KPIs: Revenue, Regional Performance, Churn, Top Products, Trends
- Insights: +15% potential revenue through regional targeting

## 📂 Project Structure
```
sales-dashboard/
 ├── data/                   # Sample dataset
 ├── notebooks/              # Python Jupyter notebooks
 ├── dashboard/              # Power BI dashboard file (add manually)
 ├── images/                 # Dashboard preview (add manually)
 ├── README.md
 └── requirements.txt
```

## ⚙️ Setup Instructions
```bash
git clone https://github.com/your-username/sales-dashboard.git
cd sales-dashboard
pip install -r requirements.txt
jupyter notebook notebooks/sales_analysis.ipynb
```

## 🛠 Tech Stack
- Python: Pandas, NumPy, Matplotlib, Seaborn
- Visualization: Power BI
- Tools: Jupyter Notebook

## 📈 Business Impact
- Identified top revenue-generating regions
- Potential +15% revenue growth with regional targeting
- Detected churn trends for retention improvement

## 📜 License
MIT License
